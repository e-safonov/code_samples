import sys
import time
import signal
import argparse
import tempfile
from daemon import Daemon


class Summoner(Daemon):
    def run(self):
        while True:
            time.sleep(1)

    def close(self):
        pass


def parse_command():
    parser = argparse.ArgumentParser(
        description='Daemon runner',
        epilog="That's all folks"
    )

    parser.add_argument('command',
                        metavar='COMMAND',
                        type=str,
                        help='usage: start|stop|restart|status',
                        choices=['start', 'stop', 'restart', 'status'])

    args = parser.parse_args()
    return args.command


def start():
    """
    The application entry point
    """
    pidfile = tempfile.gettempdir() + '/watcher.pid'
    daemon = Summoner(pidfile)
    signal.signal(signal.SIGTERM, daemon.close)

    command = parse_command()

    if command == 'start':
        print("Starting daemon")
        daemon.start()
        pid = daemon.get_pid()

        if not pid:
            print("Unable run daemon")
        else:
            print("Daemon is running [PID=%d]" % pid)

    elif command == 'stop':
        print("Stoping daemon")
        daemon.stop()

    elif command == 'restart':
        print("Restarting daemon")
        daemon.restart()

    elif command == 'status':
        print("Viewing daemon status")
        pid = daemon.get_pid()

        if not pid:
            print("Daemon isn't running ;)")
        else:
            print("Daemon is running [PID=%d]" % pid)

    sys.exit(0)


if __name__ == "__main__":
    start()
